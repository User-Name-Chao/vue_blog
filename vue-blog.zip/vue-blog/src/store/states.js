const state = {
  name: 'Test Name',
  permissionList:[],
  token:"",
  routerList:[],
  ments:[],
}
export default state
